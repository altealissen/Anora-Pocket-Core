package ru.anora.pocketcore

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Срабатывает, когда системный загрузчик закончил скачивание, даже если приложение закрыто. */
class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        val core = (context.applicationContext as AnoraApp).core
        if (id < 0 || id != core.settings.downloadId) return
        ModelDownloader.poll(context)
    }
}
