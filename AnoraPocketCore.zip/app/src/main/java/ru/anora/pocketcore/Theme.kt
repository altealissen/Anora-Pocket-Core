package ru.anora.pocketcore

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Запасная палитра для Android 11 и ниже (там нет динамических цветов Material You).
private val FallbackDark = darkColorScheme(
    primary = Color(0xFFF2B0DD),
    onPrimary = Color(0xFF4A1239),
    primaryContainer = Color(0xFF662A50),
    onPrimaryContainer = Color(0xFFFFD8EE),
    secondaryContainer = Color(0xFF574050),
    onSecondaryContainer = Color(0xFFFFD8EE),
    background = Color(0xFF16121A),
    onBackground = Color(0xFFE9E0E8),
    surface = Color(0xFF16121A),
    onSurface = Color(0xFFE9E0E8),
    surfaceVariant = Color(0xFF4E444C),
    onSurfaceVariant = Color(0xFFD1C2CB)
)

private val FallbackLight = lightColorScheme(
    primary = Color(0xFF8C3D72),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD8EE),
    onPrimaryContainer = Color(0xFF3A0B2D),
    secondaryContainer = Color(0xFFFAD8EA),
    onSecondaryContainer = Color(0xFF2B1224),
    background = Color(0xFFFFF7FA),
    onBackground = Color(0xFF1F1A1E),
    surface = Color(0xFFFFF7FA),
    onSurface = Color(0xFF1F1A1E),
    surfaceVariant = Color(0xFFEFDEE7),
    onSurfaceVariant = Color(0xFF4E444C)
)

@Composable
fun AnoraTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> FallbackDark
        else -> FallbackLight
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.surface.toArgb()
            window.navigationBarColor = scheme.surface.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }

    MaterialTheme(colorScheme = scheme, content = content)
}
