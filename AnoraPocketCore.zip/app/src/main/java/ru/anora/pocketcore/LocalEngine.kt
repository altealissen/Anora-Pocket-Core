package ru.anora.pocketcore

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/**
 * Локальный движок Anora Pocket: Qwen2.5-0.5B-Instruct (.task) через MediaPipe LLM Inference.
 * Файл модели лежит в filesDir/model.task (пользователь выбирает его в настройках).
 */
class LocalEngine(context: Context) {
    private val appContext = context.applicationContext

    @Volatile
    private var llm: LlmInference? = null

    // Папка приложения на внешнем накопителе (разрешения не нужны), туда же качает DownloadManager.
    fun modelFile(): File = File(appContext.getExternalFilesDir(null) ?: appContext.filesDir, "model.task")

    fun isModelPresent(): Boolean {
        val f = modelFile()
        return f.exists() && f.length() > 0
    }

    @Synchronized
    fun ensureLoaded() {
        if (llm != null) return
        val f = modelFile()
        if (!f.exists()) {
            throw IllegalStateException("Локальная модель не загружена. Выберите файл .task в настройках.")
        }
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(f.absolutePath)
            .setMaxTokens(MAX_TOKENS)
            .setTopK(40)
            .setTemperature(0.7f)
            .setRandomSeed(1)
            .build()
        llm = LlmInference.createFromOptions(appContext, options)
    }

    @Synchronized
    fun generate(prompt: String): String {
        ensureLoaded()
        val engine = llm ?: throw IllegalStateException("Движок не запущен")
        return engine.generateResponse(prompt)
    }

    @Synchronized
    fun release() {
        try {
            llm?.close()
        } catch (e: Exception) {
            // ignore
        }
        llm = null
    }

    companion object {
        // Должно совпадать с длиной контекста модели (ekv1280 => 1280).
        const val MAX_TOKENS = 1280

        // Бюджет промпта в символах, чтобы осталось место для ответа.
        const val PROMPT_CHAR_BUDGET = 1500

        fun buildChatMl(system: String, msgs: List<ChatMsg>): String {
            val sysBlock = "<|im_start|>system\n$system<|im_end|>\n"
            var budget = PROMPT_CHAR_BUDGET - sysBlock.length
            val parts = ArrayList<String>()
            for (i in msgs.indices.reversed()) {
                val m = msgs[i]
                if (m.role != "user" && m.role != "assistant") continue
                val block = "<|im_start|>${m.role}\n${m.content}<|im_end|>\n"
                if (block.length > budget && parts.isNotEmpty()) break
                parts.add(block)
                budget -= block.length
            }
            parts.reverse()
            return sysBlock + parts.joinToString("") + "<|im_start|>assistant\n"
        }

        fun clean(text: String): String =
            text.replace("<|im_end|>", "").replace("<|endoftext|>", "").trim()
    }
}
