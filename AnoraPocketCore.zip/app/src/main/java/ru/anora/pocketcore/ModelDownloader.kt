package ru.anora.pocketcore

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Фоновая загрузка модели через системный DownloadManager: продолжается после закрытия приложения,
 * докачивается при потере сети. Файл качается в model.task.part и переименовывается в model.task.
 */
object ModelDownloader {
    const val DEFAULT_URL =
        "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/" +
            "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val PART_NAME = "model.task.part"
    private const val MB = 1024L * 1024L
    private const val MIN_VALID_BYTES = 50L * MB

    data class DlState(
        val running: Boolean,
        val progress: Float,
        val text: String,
        val failed: Boolean = false,
        val done: Boolean = false
    )

    private fun core(ctx: Context): AnoraCore = (ctx.applicationContext as AnoraApp).core

    private fun partFile(ctx: Context): File =
        File(core(ctx).local.modelFile().parentFile, PART_NAME)

    fun start(ctx: Context) {
        val app = ctx.applicationContext
        val c = core(app)
        cancel(app)
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val url = c.settings.modelUrl.ifBlank { DEFAULT_URL }
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle("Anora Pocket: нейросеть")
            .setDescription("Qwen2.5-0.5B-Instruct")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(app, null, PART_NAME)
            .setAllowedOverMetered(!c.settings.dlWifiOnly)
            .setAllowedOverRoaming(false)
        c.settings.downloadId = dm.enqueue(req)
    }

    fun cancel(ctx: Context) {
        val app = ctx.applicationContext
        val c = core(app)
        val id = c.settings.downloadId
        if (id >= 0) {
            try {
                val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.remove(id)
            } catch (e: Exception) {
                // ignore
            }
        }
        c.settings.downloadId = -1L
        try {
            partFile(app).delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    @Synchronized
    fun finalizeDownload(ctx: Context): Boolean {
        val app = ctx.applicationContext
        val c = core(app)
        val part = partFile(app)
        if (!part.exists()) {
            c.settings.downloadId = -1L
            return c.local.isModelPresent()
        }
        if (part.length() < MIN_VALID_BYTES) {
            part.delete()
            c.settings.downloadId = -1L
            return false
        }
        c.local.release()
        val target = c.local.modelFile()
        if (target.exists()) target.delete()
        val ok = part.renameTo(target)
        c.settings.downloadId = -1L
        return ok
    }

    fun poll(ctx: Context): DlState {
        val app = ctx.applicationContext
        val c = core(app)
        val id = c.settings.downloadId
        if (id < 0) return DlState(false, 0f, "")

        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = dm.query(DownloadManager.Query().setFilterById(id))
        try {
            if (cursor == null || !cursor.moveToFirst()) {
                c.settings.downloadId = -1L
                return DlState(false, 0f, "Загрузка отменена")
            }
            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val got = cursor.getLong(
                cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
            )
            val total = cursor.getLong(
                cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
            )
            val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val frac = if (total > 0) got.toFloat() / total.toFloat() else -1f
            val totalText = if (total > 0) (total / MB).toString() else "?"
            val mb = "${got / MB} / $totalText МБ"

            return when (status) {
                DownloadManager.STATUS_SUCCESSFUL ->
                    if (finalizeDownload(app)) {
                        DlState(false, 1f, "Модель скачана", done = true)
                    } else {
                        DlState(false, 0f, "Файл повреждён, попробуйте ещё раз", failed = true)
                    }

                DownloadManager.STATUS_FAILED -> {
                    c.settings.downloadId = -1L
                    try {
                        dm.remove(id)
                    } catch (e: Exception) {
                        // ignore
                    }
                    DlState(false, 0f, "Ошибка загрузки (код $reason)", failed = true)
                }

                DownloadManager.STATUS_PAUSED, DownloadManager.STATUS_PENDING ->
                    DlState(true, frac, "Ждём подходящую сеть... $mb")

                else -> DlState(true, frac, "Скачивание... $mb")
            }
        } finally {
            cursor?.close()
        }
    }
}
