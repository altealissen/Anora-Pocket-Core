package ru.anora.pocketcore

import android.app.Application
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class UiMsg(val role: String, text: String, source: Source?) {
    var text by mutableStateOf(text)
    var source by mutableStateOf(source)
}

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    val core: AnoraCore = (app as AnoraApp).core
    private val main = Handler(Looper.getMainLooper())

    val messages = mutableStateListOf<UiMsg>()
    var busy by mutableStateOf(false)
    var mode by mutableStateOf(core.settings.mode)
    var nasState by mutableStateOf("NAS: ?")

    var modelPresent by mutableStateOf(false)
    var modelSizeMb by mutableStateOf(0L)
    var modelState by mutableStateOf("")
    var importStatus by mutableStateOf("")

    var dlRunning by mutableStateOf(false)
    var dlProgress by mutableStateOf(-1f)
    var dlText by mutableStateOf("")
    var dlFailed by mutableStateOf(false)

    private var pollJob: Job? = null

    init {
        refreshModelState()
        refreshNas()
        startPolling()
        if (core.local.isModelPresent()) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    core.local.ensureLoaded()
                } catch (e: Exception) {
                    // загрузится позже, ошибка покажется при ответе
                }
            }
        }
    }

    fun setMode(m: Mode) {
        mode = m
        core.settings.mode = m
    }

    fun refreshModelState() {
        val present = core.local.isModelPresent()
        modelPresent = present
        modelSizeMb = if (present) core.local.modelFile().length() / (1024 * 1024) else 0L
        modelState = if (present) "Pocket: готов" else "Pocket: нет модели"
    }

    fun refreshNas() {
        nasState = "NAS: проверяю..."
        viewModelScope.launch(Dispatchers.IO) {
            val up = core.nasAvailable(true)
            main.post { nasState = if (up) "NAS: онлайн" else "NAS: офлайн" }
        }
    }

    fun clearChat() {
        if (!busy) messages.clear()
    }

    // ---------- скачивание модели ----------

    fun startDownload() {
        dlFailed = false
        dlText = "Запускаю..."
        ModelDownloader.start(getApplication<Application>())
        startPolling()
    }

    fun cancelDownload() {
        ModelDownloader.cancel(getApplication<Application>())
        dlRunning = false
        dlProgress = -1f
        dlText = "Загрузка отменена"
        dlFailed = false
    }

    private fun startPolling() {
        if (pollJob?.isActive == true) return
        pollJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                val st = ModelDownloader.poll(getApplication<Application>())
                main.post {
                    dlRunning = st.running
                    dlProgress = st.progress
                    dlFailed = st.failed
                    if (st.text.isNotEmpty()) dlText = st.text
                    if (st.done) refreshModelState()
                }
                if (st.done) {
                    try {
                        core.local.ensureLoaded()
                    } catch (e: Exception) {
                        // ошибка покажется при ответе
                    }
                }
                if (!st.running) break
                delay(1000)
            }
        }
    }

    fun deleteModel() {
        viewModelScope.launch(Dispatchers.IO) {
            core.local.release()
            core.local.modelFile().delete()
            main.post {
                importStatus = ""
                dlText = ""
                refreshModelState()
            }
        }
    }

    fun importModel(uri: Uri) {
        importStatus = "Копирую модель..."
        viewModelScope.launch(Dispatchers.IO) {
            try {
                core.local.release()
                val ctx = getApplication<Application>()
                val target = core.local.modelFile()
                val tmp = java.io.File(target.parentFile, "model.task.tmp")
                var total = 0L
                val input = ctx.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Не удалось открыть файл")
                input.use { src ->
                    tmp.outputStream().use { dst ->
                        val buf = ByteArray(1024 * 1024)
                        var lastReport = 0L
                        while (true) {
                            val n = src.read(buf)
                            if (n < 0) break
                            dst.write(buf, 0, n)
                            total += n
                            if (total - lastReport > 32L * 1024 * 1024) {
                                lastReport = total
                                val mb = total / (1024 * 1024)
                                main.post { importStatus = "Копирую модель... $mb МБ" }
                            }
                        }
                    }
                }
                if (target.exists()) target.delete()
                if (!tmp.renameTo(target)) throw IllegalStateException("Не удалось сохранить модель")
                main.post {
                    importStatus = "Готово, загружаю в память..."
                    refreshModelState()
                }
                core.local.ensureLoaded()
                main.post { importStatus = "Модель готова" }
            } catch (e: Exception) {
                main.post {
                    importStatus = "Ошибка: " + (e.message ?: e.javaClass.simpleName)
                    refreshModelState()
                }
            }
        }
    }

    // ---------- чат ----------

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        messages.add(UiMsg("user", t, null))
        val reply = UiMsg("assistant", "", null)
        messages.add(reply)
        busy = true
        val history = messages.filter { it !== reply }.map { ChatMsg(it.role, it.text) }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                core.chat(
                    history,
                    null,
                    { s ->
                        main.post {
                            reply.source = s
                            reply.text = ""
                        }
                    },
                    { tok -> main.post { reply.text = reply.text + tok } }
                )
                main.post {
                    if (reply.text.isEmpty()) reply.text = "(пустой ответ)"
                    busy = false
                }
            } catch (e: Exception) {
                main.post {
                    reply.text = "⚠ " + (e.message ?: e.javaClass.simpleName)
                    busy = false
                }
            }
            val up = core.nasAvailable(false)
            main.post { nasState = if (up) "NAS: онлайн" else "NAS: офлайн" }
        }
    }
}
