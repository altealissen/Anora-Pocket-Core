package ru.anora.pocketcore

import android.content.Context

data class Answer(val text: String, val source: Source)

/**
 * Ядро Anora: решает, куда отправить запрос (Pocket или NAS), и умеет откатываться на Pocket,
 * если NAS пропал посреди запроса.
 */
class AnoraCore(context: Context) {
    val settings = Settings(context)
    val local = LocalEngine(context)
    val nas = NasClient(settings)

    @Volatile private var nasCheckedAt = 0L
    @Volatile private var nasUp = false

    fun nasAvailable(force: Boolean = false): Boolean {
        val now = System.currentTimeMillis()
        if (!force && now - nasCheckedAt < 15_000L) return nasUp
        val up = nas.isReachable()
        nasUp = up
        nasCheckedAt = System.currentTimeMillis()
        return up
    }

    private fun markNasDown() {
        nasUp = false
        nasCheckedAt = System.currentTimeMillis()
    }

    private val complexWords = Regex(
        "(почему|объясни|расскажи|напиши|сравни|придумай|составь|план|код|why|explain|write|compare|plan)",
        RegexOption.IGNORE_CASE
    )

    private fun isComplex(msgs: List<ChatMsg>): Boolean {
        val last = msgs.lastOrNull { it.role == "user" }?.content ?: return false
        return last.length > 80 || msgs.size > 6 || complexWords.containsMatchIn(last)
    }

    fun pickSource(msgs: List<ChatMsg>): Source {
        return when (settings.mode) {
            Mode.LOCAL -> Source.POCKET
            Mode.NAS -> Source.NAS
            Mode.AUTO -> {
                val up = nasAvailable()
                when {
                    !up -> Source.POCKET
                    !local.isModelPresent() -> Source.NAS
                    isComplex(msgs) -> Source.NAS
                    else -> Source.POCKET
                }
            }
        }
    }

    /**
     * msgs: только user/assistant. Системный промпт добавляется здесь.
     * onSource вызывается при выборе источника и при откате (UI должен очистить частичный ответ).
     */
    fun chat(
        msgs: List<ChatMsg>,
        systemOverride: String? = null,
        onSource: (Source) -> Unit,
        onToken: (String) -> Unit
    ): Answer {
        val system = systemOverride ?: settings.systemPrompt
        var src = pickSource(msgs)
        onSource(src)

        if (src == Source.NAS) {
            try {
                val withSystem = ArrayList<ChatMsg>()
                withSystem.add(ChatMsg("system", system))
                withSystem.addAll(msgs)
                val text = nas.chat(withSystem, onToken)
                return Answer(text.trim(), Source.NAS)
            } catch (e: Exception) {
                markNasDown()
                if (settings.mode == Mode.NAS || !local.isModelPresent()) throw e
                src = Source.POCKET
                onSource(src)
            }
        }

        val prompt = LocalEngine.buildChatMl(system, msgs)
        val text = LocalEngine.clean(local.generate(prompt))
        onToken(text)
        return Answer(text, Source.POCKET)
    }
}
