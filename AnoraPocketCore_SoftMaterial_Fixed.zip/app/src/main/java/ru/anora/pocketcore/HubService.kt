package ru.anora.pocketcore

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Хаб Anora: локальный OpenAI-совместимый сервер на 127.0.0.1:8765.
 * Любое ваше приложение на телефоне может ходить в http://127.0.0.1:8765/v1/chat/completions,
 * а Core сам решает, отвечает Pocket или NAS.
 */
class HubService : Service() {

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    private val core: AnoraCore
        get() = (application as AnoraApp).core

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (server == null) startServer()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Anora Hub", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Anora Hub работает")
            .setContentText("http://127.0.0.1:$PORT/v1")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun startServer() {
        val t = Thread {
            try {
                val s = ServerSocket(PORT, 16, InetAddress.getByName("127.0.0.1"))
                server = s
                while (!s.isClosed) {
                    val client = s.accept()
                    pool.execute { handle(client) }
                }
            } catch (e: Exception) {
                // сокет закрыт или порт занят
            }
        }
        t.isDaemon = true
        t.start()
    }

    override fun onDestroy() {
        try {
            server?.close()
        } catch (e: Exception) {
            // ignore
        }
        server = null
        pool.shutdownNow()
        super.onDestroy()
    }

    // ---------- HTTP ----------

    private fun handle(socket: Socket) {
        try {
            socket.soTimeout = 30000
            val input = BufferedInputStream(socket.getInputStream())
            val out = socket.getOutputStream()
            val head = readHead(input)
            if (head == null) {
                socket.close()
                return
            }
            val lines = head.split("\r\n")
            val first = lines[0].split(" ")
            val method = first[0]
            val path = (if (first.size > 1) first[1] else "/").substringBefore('?')

            val headers = HashMap<String, String>()
            for (i in 1 until lines.size) {
                val idx = lines[i].indexOf(':')
                if (idx > 0) {
                    headers[lines[i].substring(0, idx).trim().lowercase()] =
                        lines[i].substring(idx + 1).trim()
                }
            }

            val token = core.settings.hubToken
            if (token.isNotEmpty() && headers["authorization"] != "Bearer $token") {
                respond(out, 401, JSONObject().put("error", "unauthorized").toString())
                socket.close()
                return
            }

            var body = ""
            val len = headers["content-length"]?.toIntOrNull() ?: 0
            if (len > 0) {
                if (len > 1_000_000) {
                    respond(out, 400, JSONObject().put("error", "too large").toString())
                    socket.close()
                    return
                }
                val buf = ByteArray(len)
                DataInputStream(input).readFully(buf)
                body = String(buf, Charsets.UTF_8)
            }

            when {
                method == "GET" && path == "/health" ->
                    respond(out, 200, JSONObject().put("status", "ok").toString())

                method == "GET" && path == "/v1/models" -> {
                    val model = JSONObject().put("id", "anora").put("object", "model")
                    val res = JSONObject()
                        .put("object", "list")
                        .put("data", JSONArray().put(model))
                    respond(out, 200, res.toString())
                }

                method == "POST" && path == "/v1/chat/completions" -> chatCompletions(out, body)

                else -> respond(out, 404, JSONObject().put("error", "not found").toString())
            }
        } catch (e: Exception) {
            try {
                respond(
                    socket.getOutputStream(), 500,
                    JSONObject().put("error", e.message ?: "error").toString()
                )
            } catch (e2: Exception) {
                // ignore
            }
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun chatCompletions(out: OutputStream, body: String) {
        val req = JSONObject(body)
        val arr = req.optJSONArray("messages") ?: JSONArray()
        val msgs = ArrayList<ChatMsg>()
        var system: String? = null
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val role = m.optString("role", "user")
            val content = m.optString("content", "")
            if (role == "system") system = content else msgs.add(ChatMsg(role, content))
        }
        if (msgs.isEmpty()) {
            respond(out, 400, JSONObject().put("error", "no messages").toString())
            return
        }
        val stream = req.optBoolean("stream", false)

        val answer = core.chat(msgs, system, { }, { })
        val created = System.currentTimeMillis() / 1000
        val id = "anora-$created"

        if (stream) {
            val head = "HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n" +
                "Cache-Control: no-cache\r\nConnection: close\r\n\r\n"
            out.write(head.toByteArray())
            val delta = JSONObject().put("role", "assistant").put("content", answer.text)
            val c1 = JSONObject()
                .put("id", id).put("object", "chat.completion.chunk")
                .put("created", created).put("model", "anora")
                .put("choices", JSONArray().put(JSONObject().put("index", 0).put("delta", delta)))
            val c2 = JSONObject()
                .put("id", id).put("object", "chat.completion.chunk")
                .put("created", created).put("model", "anora")
                .put(
                    "choices", JSONArray().put(
                        JSONObject().put("index", 0).put("delta", JSONObject())
                            .put("finish_reason", "stop")
                    )
                )
            out.write(("data: $c1\n\n").toByteArray(Charsets.UTF_8))
            out.write(("data: $c2\n\n").toByteArray(Charsets.UTF_8))
            out.write("data: [DONE]\n\n".toByteArray())
            out.flush()
            return
        }

        val message = JSONObject().put("role", "assistant").put("content", answer.text)
        val choice = JSONObject()
            .put("index", 0).put("message", message).put("finish_reason", "stop")
        val res = JSONObject()
            .put("id", id).put("object", "chat.completion")
            .put("created", created).put("model", "anora")
            .put("choices", JSONArray().put(choice))
            .put("x_source", answer.source.name.lowercase())
        respond(out, 200, res.toString())
    }

    private fun respond(out: OutputStream, code: Int, body: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val status = when (code) {
            200 -> "OK"
            400 -> "Bad Request"
            401 -> "Unauthorized"
            404 -> "Not Found"
            else -> "Error"
        }
        val head = "HTTP/1.1 $code $status\r\n" +
            "Content-Type: application/json; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray())
        out.write(bytes)
        out.flush()
    }

    private fun readHead(input: InputStream): String? {
        val buf = ByteArrayOutputStream()
        var state = 0
        while (buf.size() < 16384) {
            val b = input.read()
            if (b < 0) return null
            buf.write(b)
            state = when {
                b == 13 && (state == 0 || state == 2) -> state + 1
                b == 10 && (state == 1 || state == 3) -> state + 1
                b == 13 -> 1
                else -> 0
            }
            if (state == 4) {
                return String(buf.toByteArray(), Charsets.UTF_8).removeSuffix("\r\n\r\n")
            }
        }
        return null
    }

    companion object {
        const val PORT = 8765
        private const val CHANNEL = "anora_hub"
        private const val NOTIF_ID = 1
    }
}
