package ru.anora.pocketcore

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vm = ViewModelProvider(this)[ChatViewModel::class.java]

        if (vm.core.settings.hubEnabled) {
            ContextCompat.startForegroundService(this, Intent(this, HubService::class.java))
        }

        setContent {
            AnoraTheme {
                AnoraScreen(vm)
            }
        }
    }
}
