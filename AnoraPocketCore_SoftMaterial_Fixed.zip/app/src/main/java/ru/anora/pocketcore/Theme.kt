package ru.anora.pocketcore

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val AnoraLight = lightColorScheme(
    primary = Color(0xFF8756A5), onPrimary = Color.White,
    primaryContainer = Color(0xFFEAD9F5), onPrimaryContainer = Color(0xFF382344),
    secondary = Color(0xFFB86F88), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDCE7), onSecondaryContainer = Color(0xFF482633),
    background = Color(0xFFFFF5F6), onBackground = Color(0xFF302431),
    surface = Color(0xFFFFFAFC), onSurface = Color(0xFF302431),
    surfaceVariant = Color(0xFFF3E7F0), onSurfaceVariant = Color(0xFF776574),
    outline = Color(0xFFD9C6D5)
)

private val AnoraDark = darkColorScheme(
    primary = Color(0xFFE0B8F2), onPrimary = Color(0xFF40234D),
    primaryContainer = Color(0xFF5D3C6B), onPrimaryContainer = Color(0xFFF5DFFF),
    secondary = Color(0xFFF0B6C9), onSecondary = Color(0xFF512B3A),
    secondaryContainer = Color(0xFF633D4D), onSecondaryContainer = Color(0xFFFFDCE7),
    background = Color(0xFF211A24), onBackground = Color(0xFFF3E8F2),
    surface = Color(0xFF29212D), onSurface = Color(0xFFF3E8F2),
    surfaceVariant = Color(0xFF493B4C), onSurfaceVariant = Color(0xFFD4C2D4),
    outline = Color(0xFF806D82)
)

@Composable
fun AnoraTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) AnoraDark else AnoraLight
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        val window = (view.context as Activity).window
        window.statusBarColor = scheme.background.toArgb()
        window.navigationBarColor = scheme.background.toArgb()
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
