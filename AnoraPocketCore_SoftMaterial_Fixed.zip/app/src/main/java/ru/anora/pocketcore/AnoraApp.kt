package ru.anora.pocketcore

import android.app.Application

class AnoraApp : Application() {
    lateinit var core: AnoraCore
        private set

    override fun onCreate() {
        super.onCreate()
        core = AnoraCore(this)
    }
}
