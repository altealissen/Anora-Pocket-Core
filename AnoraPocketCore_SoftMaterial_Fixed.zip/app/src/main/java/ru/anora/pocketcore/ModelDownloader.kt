package ru.anora.pocketcore

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/** Надёжная загрузка и установка .task через системный DownloadManager. */
object ModelDownloader {
    const val DEFAULT_URL =
        "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/" +
            "Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    const val PART_NAME = "model.task.part"
    private const val MB = 1024L * 1024L
    private const val MIN_VALID_BYTES = 500L * MB
    // SHA-256 опубликован для этого же файла модели в Hugging Face Xet pointer.
    private const val DEFAULT_SHA256 = "e608953f169aeb1bd7b9155fec2559825e08453fc209b84eda3a781ed0452fd2"

    data class DlState(
        val running: Boolean,
        val progress: Float,
        val text: String,
        val failed: Boolean = false,
        val done: Boolean = false
    )

    private fun core(ctx: Context): AnoraCore = (ctx.applicationContext as AnoraApp).core

    /** Не запускаем дубликат, если DownloadManager уже выполняет или завершил эту загрузку. */
    @Synchronized
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        val c = core(app)
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val existingId = c.settings.downloadId
        if (existingId >= 0) {
            val cursor = dm.query(DownloadManager.Query().setFilterById(existingId))
            val exists = try { cursor != null && cursor.moveToFirst() } finally { cursor?.close() }
            if (exists) return
            c.settings.downloadId = -1L
        }

        val url = c.settings.modelUrl.ifBlank { DEFAULT_URL }
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle("Anora Pocket: нейросеть")
            .setDescription("Qwen2.5-0.5B-Instruct · около 547 МБ")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(app, null, PART_NAME)
            .setAllowedOverMetered(!c.settings.dlWifiOnly)
            .setAllowedOverRoaming(false)
        c.settings.downloadId = dm.enqueue(req)
    }

    /** Отмена пользователем: удаляем запись DownloadManager и временный файл. */
    fun cancel(ctx: Context) {
        val app = ctx.applicationContext
        val c = core(app)
        val id = c.settings.downloadId
        if (id >= 0) {
            try { (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(id) }
            catch (_: Exception) { }
        }
        c.settings.downloadId = -1L
        File(c.local.modelFile().parentFile, PART_NAME).delete()
        File(c.local.modelFile().parentFile, "model.task.installing").delete()
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /** Копируем из открытого DownloadManager-дескриптора, а не угадываем путь его временного файла. */
    @Synchronized
    private fun finalizeDownload(ctx: Context, id: Long): String? {
        val app = ctx.applicationContext
        val c = core(app)
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val target = c.local.modelFile()
        val staging = File(target.parentFile, "model.task.installing")
        try {
            target.parentFile?.mkdirs()
            staging.delete()
            dm.openDownloadedFile(id).use { pfd ->
                FileInputStream(pfd.fileDescriptor).use { input ->
                    FileOutputStream(staging).use { output ->
                        val buffer = ByteArray(1024 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                        }
                        output.fd.sync()
                    }
                }
            }
            if (!staging.exists() || staging.length() < MIN_VALID_BYTES) {
                val actualMb = if (staging.exists()) staging.length() / MB else 0L
                staging.delete()
                return "Загрузчик сообщил 100%, но файл неполный ($actualMb МБ). Удалите загрузку и попробуйте ещё раз."
            }
            val requestedUrl = c.settings.modelUrl.ifBlank { DEFAULT_URL }
            if (requestedUrl == DEFAULT_URL) {
                val actual = sha256(staging)
                if (!actual.equals(DEFAULT_SHA256, ignoreCase = true)) {
                    staging.delete()
                    return "Проверка SHA-256 не пройдена. Файл повреждён; скачайте модель повторно."
                }
            }
            c.local.release()
            if (target.exists() && !target.delete()) {
                staging.delete()
                return "Не удалось заменить старый файл модели. Освободите место и повторите."
            }
            if (!staging.renameTo(target)) {
                // Fallback для файловых систем, где renameTo не сработал.
                FileInputStream(staging).use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output); output.fd.sync() }
                }
                staging.delete()
            }
            if (!target.exists() || target.length() < MIN_VALID_BYTES) {
                target.delete()
                return "Не удалось сохранить полный файл модели. Проверьте свободное место."
            }
            return null
        } catch (e: Exception) {
            staging.delete()
            return "Не удалось установить модель: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun poll(ctx: Context): DlState {
        val app = ctx.applicationContext
        val c = core(app)
        val id = c.settings.downloadId
        if (id < 0) return DlState(false, 0f, "")
        val dm = app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = dm.query(DownloadManager.Query().setFilterById(id))
        try {
            if (cursor == null || !cursor.moveToFirst()) {
                c.settings.downloadId = -1L
                return DlState(false, 0f, "Не найдена задача загрузки. Нажмите «Скачать нейросеть» ещё раз.", failed = true)
            }
            val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val got = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val frac = if (total > 0) (got.toFloat() / total.toFloat()).coerceIn(0f, 1f) else -1f
            val totalText = if (total > 0) (total / MB).toString() else "?"
            val mb = "${got / MB} / $totalText МБ"

            return when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val error = finalizeDownload(app, id)
                    c.settings.downloadId = -1L
                    try { dm.remove(id) } catch (_: Exception) { }
                    if (error == null) {
                        DlState(false, 1f, "Модель проверена и установлена (${c.local.modelFile().length() / MB} МБ)", done = true)
                    } else {
                        DlState(false, 0f, error, failed = true)
                    }
                }
                DownloadManager.STATUS_FAILED -> {
                    c.settings.downloadId = -1L
                    try { dm.remove(id) } catch (_: Exception) { }
                    val why = when (reason) {
                        DownloadManager.ERROR_CANNOT_RESUME -> "сервер не поддержал продолжение загрузки"
                        DownloadManager.ERROR_DEVICE_NOT_FOUND -> "накопитель недоступен"
                        DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "файл уже существует"
                        DownloadManager.ERROR_FILE_ERROR -> "ошибка записи файла или недостаточно места"
                        DownloadManager.ERROR_HTTP_DATA_ERROR -> "ошибка передачи данных"
                        DownloadManager.ERROR_INSUFFICIENT_SPACE -> "недостаточно свободного места"
                        DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "слишком много перенаправлений"
                        DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "сервер вернул HTTP-ошибку"
                        DownloadManager.ERROR_UNKNOWN -> "неизвестная ошибка загрузчика"
                        else -> "код $reason"
                    }
                    DlState(false, 0f, "Не удалось скачать модель: $why", failed = true)
                }
                DownloadManager.STATUS_PAUSED, DownloadManager.STATUS_PENDING ->
                    DlState(true, frac, "Ожидание сети или свободного места… $mb")
                else -> DlState(true, frac, "Скачивание… $mb")
            }
        } finally { cursor?.close() }
    }
}
