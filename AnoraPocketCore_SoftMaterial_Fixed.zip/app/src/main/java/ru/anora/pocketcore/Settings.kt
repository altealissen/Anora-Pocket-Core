package ru.anora.pocketcore

import android.content.Context
import android.content.SharedPreferences

enum class Mode { AUTO, LOCAL, NAS }

enum class Source { POCKET, NAS }

data class ChatMsg(val role: String, val content: String)

class Settings(context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("anora", Context.MODE_PRIVATE)

    var nasUrl: String
        get() = p.getString("nasUrl", "") ?: ""
        set(v) { p.edit().putString("nasUrl", v.trim()).apply() }

    var nasModel: String
        get() = p.getString("nasModel", "qwen2.5:3b") ?: "qwen2.5:3b"
        set(v) { p.edit().putString("nasModel", v.trim()).apply() }

    var nasKey: String
        get() = p.getString("nasKey", "") ?: ""
        set(v) { p.edit().putString("nasKey", v.trim()).apply() }

    var systemPrompt: String
        get() = p.getString("systemPrompt", DEFAULT_SYSTEM) ?: DEFAULT_SYSTEM
        set(v) { p.edit().putString("systemPrompt", v).apply() }

    var mode: Mode
        get() = try {
            Mode.valueOf(p.getString("mode", "AUTO") ?: "AUTO")
        } catch (e: Exception) {
            Mode.AUTO
        }
        set(v) { p.edit().putString("mode", v.name).apply() }

    var hubEnabled: Boolean
        get() = p.getBoolean("hubEnabled", false)
        set(v) { p.edit().putBoolean("hubEnabled", v).apply() }

    var hubToken: String
        get() = p.getString("hubToken", "") ?: ""
        set(v) { p.edit().putString("hubToken", v.trim()).apply() }

    var modelUrl: String
        get() = p.getString("modelUrl", ModelDownloader.DEFAULT_URL) ?: ModelDownloader.DEFAULT_URL
        set(v) { p.edit().putString("modelUrl", v.trim()).apply() }

    var dlWifiOnly: Boolean
        get() = p.getBoolean("dlWifiOnly", true)
        set(v) { p.edit().putBoolean("dlWifiOnly", v).apply() }

    var downloadId: Long
        get() = p.getLong("downloadId", -1L)
        set(v) { p.edit().putLong("downloadId", v).apply() }

    companion object {
        const val DEFAULT_SYSTEM =
            "Ты Anora, личный ИИ-ассистент. Отвечай кратко и по делу, по-русски, если не попросили иначе."
    }
}
