package ru.anora.pocketcore

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * DownloadManager сохраняет результат независимо от процесса приложения.
 * Финальная проверка/установка выполняется при следующем poll на IO-потоке,
 * чтобы не копировать и не хешировать файл размером 547 МБ в onReceive.
 */
class DownloadReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        // Ничего не делаем на главном потоке: ViewModel завершит установку при poll().
    }
}
