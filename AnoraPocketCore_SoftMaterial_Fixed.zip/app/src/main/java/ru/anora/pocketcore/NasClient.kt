package ru.anora.pocketcore

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Клиент большой Anora на NAS (Ollama, OpenAI-совместимый API).
 * Адрес вводится вместе с /v1, например http://192.168.1.50:11434/v1
 */
class NasClient(private val settings: Settings) {

    private fun base(): String = settings.nasUrl.trimEnd('/')

    private fun open(path: String, method: String, connectMs: Int, readMs: Int): HttpURLConnection {
        val c = URL(base() + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        val key = settings.nasKey
        if (key.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $key")
        return c
    }

    fun isReachable(): Boolean {
        if (base().isEmpty()) return false
        return try {
            val c = open("/models", "GET", 1500, 1500)
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (e: Exception) {
            false
        }
    }

    fun chat(messages: List<ChatMsg>, onToken: (String) -> Unit): String {
        if (base().isEmpty()) throw IllegalStateException("Адрес NAS не задан в настройках")

        val arr = JSONArray()
        for (m in messages) {
            arr.put(JSONObject().put("role", m.role).put("content", m.content))
        }
        val body = JSONObject()
            .put("model", settings.nasModel)
            .put("messages", arr)
            .put("stream", true)
            .toString()

        val c = open("/chat/completions", "POST", 3000, 120000)
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

        val code = c.responseCode
        if (code !in 200..299) {
            val err = try {
                c.errorStream?.bufferedReader()?.readText() ?: ""
            } catch (e: Exception) {
                ""
            }
            c.disconnect()
            throw IllegalStateException("NAS ответил $code ${err.take(200)}")
        }

        val full = StringBuilder()
        BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { reader ->
            while (true) {
                val line = reader.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val payload = line.removePrefix("data:").trim()
                if (payload.isEmpty()) continue
                if (payload == "[DONE]") break
                try {
                    val choices = JSONObject(payload).optJSONArray("choices") ?: continue
                    if (choices.length() == 0) continue
                    val delta = choices.getJSONObject(0).optJSONObject("delta") ?: continue
                    val piece = delta.optString("content", "")
                    if (piece.isNotEmpty()) {
                        full.append(piece)
                        onToken(piece)
                    }
                } catch (e: Exception) {
                    // пропускаем битый кусок потока
                }
            }
        }
        c.disconnect()
        return full.toString()
    }
}
