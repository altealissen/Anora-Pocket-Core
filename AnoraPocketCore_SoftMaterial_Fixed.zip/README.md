# Anora Pocket Core

Android-приложение, ядро Anora на телефоне (Material You, динамические цвета Android 12+):

- чат с локальной Qwen2.5-0.5B (MediaPipe LLM Inference, полностью офлайн);
- переключатель на главном экране: Pocket / Авто / NAS (большая Anora по Wi-Fi);
- кнопка «Скачать нейросеть» в настройках: скачивание в фоне, работает при закрытом приложении;
- хаб: локальный OpenAI-совместимый сервер http://127.0.0.1:8765/v1 для других ваших приложений.

## Первый запуск

1. Установить APK.
2. Настройки -> «Скачать нейросеть (≈547 МБ)». Можно закрыть приложение, загрузка продолжится.
   (Вручную: выбрать скачанный .task через «Выбрать файл вручную».)
3. Там же указать адрес NAS, например `http://192.168.1.50:11434/v1`, и модель (`qwen2.5:3b`).
4. На главном экране выбрать режим: Pocket, Авто или NAS.

## Режимы

- Pocket: всегда локальная модель, без сети.
- NAS: всегда большая Anora на NAS. Если NAS недоступен, будет ошибка.
- Авто: короткие запросы отвечает Pocket, сложные уходят на NAS, если он доступен.
  Если NAS пропал посреди ответа, ответ повторяется на Pocket.

## Сборка

Положить ZIP и `.github/workflows/build.yml` в GitHub-репозиторий, APK соберётся в Actions.

## Anora Soft Material redesign

The chat UI now uses a custom pastel pink/lavender palette, a branded welcome state, Pocket/Auto/NAS selector, source labels, generation state, and rounded message composer. Three mascot pose crops are bundled in `app/src/main/res/drawable-nodpi/` (`anora_hello`, `anora_thinking`, `anora_answer`). Existing model, NAS, downloader, and local hub logic is retained.

## Fix: проверка и установка загруженной модели

- После статуса DownloadManager `SUCCESSFUL` файл читается через `openDownloadedFile(id)`, а не по предположительному пути назначения.
- Модель копируется во временный `model.task.installing`, синхронизируется на диск и только затем заменяет `model.task`.
- Для штатной Qwen2.5-0.5B проверяются минимальный размер 500 МиБ и SHA-256 `e608953f169aeb1bd7b9155fec2559825e08453fc209b84eda3a781ed0452fd2`.
- При несовпадении размера или контрольной суммы приложение показывает причину и не помечает модель готовой.
- Повторное нажатие «Скачать нейросеть» не создаёт вторую задачу, если предыдущая ещё существует в DownloadManager.
- Проверка и копирование большого файла выполняются в IO-потоке через polling, а не в `BroadcastReceiver.onReceive`.
