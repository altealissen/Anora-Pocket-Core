package ru.anora.pocketcore

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@Composable
fun AnoraScreen(vm: ChatViewModel) {
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showSettings) { showSettings = false }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (showSettings) "Настройки" else "Anora") },
                actions = {
                    TextButton(onClick = { showSettings = !showSettings }) {
                        Text(if (showSettings) "Чат" else "Настройки")
                    }
                }
            )
        }
    ) { inner ->
        Column(
            Modifier
                .padding(inner)
                .fillMaxSize()
        ) {
            if (showSettings) {
                SettingsScreen(vm, Modifier.weight(1f))
            } else {
                ModeSwitcher(vm)
                StatusLine(vm)
                ChatList(vm, Modifier.weight(1f))
                InputBar(vm)
            }
        }
    }
}

@Composable
private fun ModeSwitcher(vm: ChatViewModel) {
    val items = listOf(Mode.LOCAL to "Pocket", Mode.AUTO to "Авто", Mode.NAS to "NAS")
    SingleChoiceSegmentedButtonRow(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        items.forEachIndexed { index, item ->
            SegmentedButton(
                selected = vm.mode == item.first,
                onClick = { vm.selectMode(item.first) },
                shape = SegmentedButtonDefaults.itemShape(index = index, count = items.size)
            ) {
                Text(item.second)
            }
        }
    }
}

@Composable
private fun StatusLine(vm: ChatViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "${vm.modelState} · ${vm.nasState}",
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        TextButton(onClick = { vm.refreshNas() }) { Text("↻") }
    }
}

@Composable
private fun ChatList(vm: ChatViewModel, modifier: Modifier) {
    val listState = rememberLazyListState()
    val size = vm.messages.size
    val lastLen = vm.messages.lastOrNull()?.text?.length ?: 0

    LaunchedEffect(size, lastLen) {
        if (size > 0) listState.scrollToItem(size - 1)
    }

    if (size == 0) {
        Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(
                "Напиши что-нибудь Anora",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    val cs = MaterialTheme.colorScheme
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        state = listState,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(size) { index ->
            val m = vm.messages[index]
            val isUser = m.role == "user"
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
            ) {
                Surface(
                    color = if (isUser) cs.primaryContainer else cs.surfaceContainerHigh,
                    contentColor = if (isUser) cs.onPrimaryContainer else cs.onSurface,
                    shape = RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = if (isUser) 20.dp else 6.dp,
                        bottomEnd = if (isUser) 6.dp else 20.dp
                    ),
                    modifier = Modifier.widthIn(max = 320.dp)
                ) {
                    Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        if (!isUser) {
                            val label = when (m.source) {
                                Source.POCKET -> "Anora · Pocket"
                                Source.NAS -> "Anora · NAS"
                                null -> "Anora"
                            }
                            Text(
                                label,
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.primary
                            )
                        }
                        Text(
                            if (m.text.isEmpty()) "…" else m.text,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InputBar(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Сообщение") },
            shape = RoundedCornerShape(28.dp),
            maxLines = 4
        )
        Spacer(Modifier.width(8.dp))
        FilledIconButton(
            onClick = {
                if (!vm.busy && input.isNotBlank()) {
                    vm.send(input)
                    input = ""
                }
            },
            enabled = !vm.busy,
            modifier = Modifier.size(56.dp)
        ) {
            Text(if (vm.busy) "…" else "➤")
        }
    }
}

@Composable
private fun SettingsScreen(vm: ChatViewModel, modifier: Modifier) {
    val s = vm.core.settings
    val ctx = LocalContext.current

    var nasUrl by remember { mutableStateOf(s.nasUrl) }
    var nasModel by remember { mutableStateOf(s.nasModel) }
    var nasKey by remember { mutableStateOf(s.nasKey) }
    var system by remember { mutableStateOf(s.systemPrompt) }
    var hub by remember { mutableStateOf(s.hubEnabled) }
    var hubToken by remember { mutableStateOf(s.hubToken) }
    var wifiOnly by remember { mutableStateOf(s.dlWifiOnly) }
    var modelUrl by remember { mutableStateOf(s.modelUrl) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) vm.importModel(uri)
    }

    Column(
        modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        SettingsCard("Pocket: офлайн-нейросеть") {
            Text(
                if (vm.modelPresent) "Модель установлена (${vm.modelSizeMb} МБ)" else "Модель не установлена",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))

            if (vm.dlRunning) {
                if (vm.dlProgress >= 0f) {
                    LinearProgressIndicator(
                        progress = { vm.dlProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
                Text(vm.dlText, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.cancelDownload() }) { Text("Отменить загрузку") }
                Hint("Приложение можно закрыть: скачивание продолжится в фоне.")
            } else {
                if (vm.dlText.isNotEmpty()) {
                    Text(
                        vm.dlText,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (vm.dlFailed) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                }
                Button(onClick = { vm.startDownload() }) {
                    Text(if (vm.modelPresent) "Скачать заново" else "Скачать нейросеть (≈547 МБ)")
                }
            }

            Spacer(Modifier.height(8.dp))
            SwitchRow("Качать только по Wi-Fi", wifiOnly) {
                wifiOnly = it
                s.dlWifiOnly = it
            }
            SField("Ссылка на модель (.task)", modelUrl, { modelUrl = it; s.modelUrl = it })

            Row {
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                    Text("Выбрать файл вручную")
                }
                if (vm.modelPresent) {
                    TextButton(onClick = { vm.deleteModel() }) { Text("Удалить модель") }
                }
            }
            if (vm.importStatus.isNotEmpty()) {
                Text(
                    vm.importStatus,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        SettingsCard("NAS: большая Anora (по Wi-Fi)") {
            SField(
                "Адрес API, например http://192.168.1.50:11434/v1",
                nasUrl,
                { nasUrl = it; s.nasUrl = it }
            )
            SField("Модель на NAS", nasModel, { nasModel = it; s.nasModel = it })
            SField("API-ключ (если нужен)", nasKey, { nasKey = it; s.nasKey = it }, secret = true)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = { vm.refreshNas() }) { Text("Проверить связь") }
                Spacer(Modifier.width(12.dp))
                Text(vm.nasState, style = MaterialTheme.typography.labelLarge)
            }
            Hint("Режим ответа (Pocket, Авто или NAS) переключается на главном экране. В режиме «Авто» сложные запросы уходят на NAS, если он доступен.")
        }

        SettingsCard("Личность Anora") {
            SField("Системный промпт", system, { system = it; s.systemPrompt = it }, singleLine = false)
        }

        SettingsCard("Хаб для других приложений") {
            SwitchRow("Локальный сервер включён", hub) { on ->
                hub = on
                s.hubEnabled = on
                val intent = Intent(ctx, HubService::class.java)
                if (on) ContextCompat.startForegroundService(ctx, intent) else ctx.stopService(intent)
            }
            SField("Токен (необязательно)", hubToken, { hubToken = it; s.hubToken = it }, secret = true)
            Hint("OpenAI-совместимый адрес для ваших приложений: http://127.0.0.1:${HubService.PORT}/v1 (модель anora). Доступен только на этом телефоне.")
        }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.clearChat() }) { Text("Очистить чат") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        modifier = Modifier.padding(top = 8.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    secret: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}
