package ru.anora.pocketcore

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun AnoraScreen(vm: ChatViewModel) {
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showSettings) { showSettings = false }
    val bg = Brush.verticalGradient(listOf(Color(0xFFFFF3F5), Color(0xFFF5EDFF), Color(0xFFFFF8F1)))
    Scaffold(containerColor = Color.Transparent) { inner ->
        Column(Modifier.fillMaxSize().background(bg).padding(inner)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (showSettings) "ТВОЁ ПРОСТРАНСТВО" else "ANORA POCKET", fontSize = 10.sp, letterSpacing = 2.sp, color = Color(0xFF9B718D), fontWeight = FontWeight.Bold)
                    Text(if (showSettings) "Настройки" else "Привет, я Anora", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color(0xFF302431))
                }
                Surface(onClick = { showSettings = !showSettings }, shape = CircleShape, color = Color.White.copy(alpha=.82f), shadowElevation = 2.dp) {
                    Text(if (showSettings) "✦ Чат" else "⚙", Modifier.padding(horizontal = 17.dp, vertical = 12.dp), color = Color(0xFF87517A), fontWeight = FontWeight.SemiBold)
                }
            }
            if (showSettings) SettingsScreen(vm, Modifier.weight(1f)) else {
                ModeSwitcher(vm)
                StatusLine(vm)
                ChatList(vm, Modifier.weight(1f))
                InputBar(vm)
            }
        }
    }
}

@Composable
private fun ModeSwitcher(vm: ChatViewModel) {
    val items = listOf(Mode.LOCAL to "Pocket", Mode.AUTO to "Авто", Mode.NAS to "NAS")
    Surface(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=7.dp), shape=RoundedCornerShape(22.dp), color=Color.White.copy(alpha=.72f)) {
        Row(Modifier.padding(5.dp), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
            items.forEach { item ->
                val selected = vm.mode == item.first
                Surface(onClick = { vm.selectMode(item.first) }, modifier=Modifier.weight(1f), shape=RoundedCornerShape(17.dp), color=if(selected) Color(0xFF8050A5) else Color.Transparent) {
                    Text(item.second, Modifier.padding(vertical=11.dp), textAlign=androidx.compose.ui.text.style.TextAlign.Center, color=if(selected) Color.White else Color(0xFF755D72), fontWeight=FontWeight.SemiBold, fontSize=13.sp)
                }
            }
        }
    }
}

@Composable
private fun StatusLine(vm: ChatViewModel) {
    Row(Modifier.fillMaxWidth().padding(horizontal=22.dp, vertical=5.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(if(vm.nasState.contains("онлайн")) Color(0xFF55B98A) else Color(0xFFB9A4B6)))
        Text("  ${vm.modelState}  ·  ${vm.nasState}", Modifier.weight(1f), fontSize=11.sp, color=Color(0xFF8C7889), maxLines=1)
        TextButton(onClick={vm.refreshNas()}, contentPadding=PaddingValues(horizontal=5.dp, vertical=0.dp)) { Text("↻", color=Color(0xFF87517A), fontSize=18.sp) }
    }
}

@Composable
private fun ChatList(vm: ChatViewModel, modifier: Modifier) {
    val listState = rememberLazyListState()
    val count = vm.messages.size
    val lastLen = vm.messages.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(count,lastLen,vm.busy) { if(count>0) listState.animateScrollToItem(count-1) }
    if(count==0) {
        Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=22.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
            Spacer(Modifier.height(8.dp))
            Image(painterResource(R.drawable.anora_hello), null, Modifier.fillMaxWidth(.88f).height(235.dp).clip(RoundedCornerShape(30.dp)), contentScale=ContentScale.Crop, alignment=Alignment.TopCenter)
            Spacer(Modifier.height(10.dp))
            Text("Я рядом ✨", fontSize=23.sp, fontWeight=FontWeight.Bold, color=Color(0xFF493448))
            Text("Спроси меня о чём угодно —\\nили просто расскажи, что у тебя на уме.", textAlign=androidx.compose.ui.text.style.TextAlign.Center, color=Color(0xFF8B7588), fontSize=14.sp, lineHeight=20.sp)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                SuggestionChip("Привет, Anora")
                SuggestionChip("Помоги с идеей")
            }
        }
        return
    }
    LazyColumn(modifier.fillMaxWidth(), state=listState, contentPadding=PaddingValues(horizontal=15.dp, vertical=12.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        items(count) { index ->
            val m=vm.messages[index]; val user=m.role=="user"
            Row(Modifier.fillMaxWidth(), horizontalArrangement=if(user) Arrangement.End else Arrangement.Start, verticalAlignment=Alignment.Bottom) {
                if(!user) Image(painterResource(R.drawable.anora_answer), null, Modifier.size(38.dp).clip(CircleShape), contentScale=ContentScale.Crop)
                Spacer(Modifier.width(if(user) 34.dp else 8.dp))
                Surface(color=if(user) Color(0xFFE8D7F4) else Color.White.copy(alpha=.94f), shape=RoundedCornerShape(22.dp,22.dp,if(user) 7.dp else 22.dp,if(user) 22.dp else 7.dp), shadowElevation=1.dp, modifier=Modifier.widthIn(max=310.dp)) {
                    Column(Modifier.padding(horizontal=15.dp, vertical=11.dp)) {
                        if(!user) Text(when(m.source){Source.POCKET->"ANORA · POCKET";Source.NAS->"ANORA · NAS";null->"ANORA"}, fontSize=9.sp, letterSpacing=1.3.sp, color=Color(0xFF9865A0), fontWeight=FontWeight.Bold)
                        Text(if(m.text.isEmpty()) "…" else m.text, color=Color(0xFF382D39), fontSize=15.sp, lineHeight=21.sp)
                    }
                }
                Spacer(Modifier.width(if(user) 0.dp else 8.dp))
            }
        }
        if(vm.busy) item {
            Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
                Image(painterResource(R.drawable.anora_thinking), null, Modifier.size(56.dp).clip(CircleShape), contentScale=ContentScale.Crop)
                Surface(color=Color.White.copy(alpha=.9f), shape=RoundedCornerShape(18.dp)) { Text("Anora думает… ✨", Modifier.padding(horizontal=15.dp, vertical=11.dp), color=Color(0xFF87517A), fontSize=13.sp) }
            }
        }
    }
}

@Composable
private fun SuggestionChip(label:String) {
    Surface(shape=RoundedCornerShape(18.dp), color=Color.White.copy(alpha=.85f)) { Text(label, Modifier.padding(horizontal=13.dp, vertical=9.dp), color=Color(0xFF805B7B), fontSize=12.sp) }
}

@Composable
private fun InputBar(vm: ChatViewModel) {
    var input by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=10.dp), shape=RoundedCornerShape(27.dp), color=Color.White, shadowElevation=5.dp) {
        Row(Modifier.padding(start=17.dp,end=7.dp,top=5.dp,bottom=5.dp), verticalAlignment=Alignment.CenterVertically) {
            androidx.compose.material3.TextField(value=input,onValueChange={input=it},modifier=Modifier.weight(1f),placeholder={Text("Напиши Anora…",color=Color(0xFFB19EAE))},maxLines=4,colors=TextFieldDefaults.colors(focusedContainerColor=Color.Transparent,unfocusedContainerColor=Color.Transparent,focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent),textStyle=MaterialTheme.typography.bodyLarge)
            Surface(onClick={if(!vm.busy && input.isNotBlank()){vm.send(input);input=""}},shape=CircleShape,color=if(vm.busy) Color(0xFFCDBBD0) else Color(0xFF8756A5)) {
                Text(if(vm.busy) "…" else "➤",Modifier.padding(horizontal=15.dp,vertical=12.dp),color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SettingsScreen(vm: ChatViewModel, modifier: Modifier) {
    val s = vm.core.settings
    val ctx = LocalContext.current

    var nasUrl by remember { mutableStateOf(s.nasUrl) }
    var nasModel by remember { mutableStateOf(s.nasModel) }
    var nasKey by remember { mutableStateOf(s.nasKey) }
    var system by remember { mutableStateOf(s.systemPrompt) }
    var hub by remember { mutableStateOf(s.hubEnabled) }
    var hubToken by remember { mutableStateOf(s.hubToken) }
    var wifiOnly by remember { mutableStateOf(s.dlWifiOnly) }
    var modelUrl by remember { mutableStateOf(s.modelUrl) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) vm.importModel(uri)
    }

    Column(
        modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        SettingsCard("Pocket: офлайн-нейросеть") {
            Text(
                if (vm.modelPresent) "Модель установлена (${vm.modelSizeMb} МБ)" else "Модель не установлена",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))

            if (vm.dlRunning) {
                if (vm.dlProgress >= 0f) {
                    LinearProgressIndicator(
                        progress = { vm.dlProgress },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
                Text(vm.dlText, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.cancelDownload() }) { Text("Отменить загрузку") }
                Hint("Приложение можно закрыть: скачивание продолжится в фоне.")
            } else {
                if (vm.dlText.isNotEmpty()) {
                    Text(
                        vm.dlText,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (vm.dlFailed) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                }
                Button(onClick = { vm.startDownload() }) {
                    Text(if (vm.modelPresent) "Скачать заново" else "Скачать нейросеть (≈547 МБ)")
                }
            }

            Spacer(Modifier.height(8.dp))
            SwitchRow("Качать только по Wi-Fi", wifiOnly) {
                wifiOnly = it
                s.dlWifiOnly = it
            }
            SField("Ссылка на модель (.task)", modelUrl, { modelUrl = it; s.modelUrl = it })

            Row {
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) {
                    Text("Выбрать файл вручную")
                }
                if (vm.modelPresent) {
                    TextButton(onClick = { vm.deleteModel() }) { Text("Удалить модель") }
                }
            }
            if (vm.importStatus.isNotEmpty()) {
                Text(
                    vm.importStatus,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        SettingsCard("NAS: большая Anora (по Wi-Fi)") {
            SField(
                "Адрес API, например http://192.168.1.50:11434/v1",
                nasUrl,
                { nasUrl = it; s.nasUrl = it }
            )
            SField("Модель на NAS", nasModel, { nasModel = it; s.nasModel = it })
            SField("API-ключ (если нужен)", nasKey, { nasKey = it; s.nasKey = it }, secret = true)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(onClick = { vm.refreshNas() }) { Text("Проверить связь") }
                Spacer(Modifier.width(12.dp))
                Text(vm.nasState, style = MaterialTheme.typography.labelLarge)
            }
            Hint("Режим ответа (Pocket, Авто или NAS) переключается на главном экране. В режиме «Авто» сложные запросы уходят на NAS, если он доступен.")
        }

        SettingsCard("Личность Anora") {
            SField("Системный промпт", system, { system = it; s.systemPrompt = it }, singleLine = false)
        }

        SettingsCard("Хаб для других приложений") {
            SwitchRow("Локальный сервер включён", hub) { on ->
                hub = on
                s.hubEnabled = on
                val intent = Intent(ctx, HubService::class.java)
                if (on) ContextCompat.startForegroundService(ctx, intent) else ctx.stopService(intent)
            }
            SField("Токен (необязательно)", hubToken, { hubToken = it; s.hubToken = it }, secret = true)
            Hint("OpenAI-совместимый адрес для ваших приложений: http://127.0.0.1:${HubService.PORT}/v1 (модель anora). Доступен только на этом телефоне.")
        }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.clearChat() }) { Text("Очистить чат") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        modifier = Modifier.padding(top = 8.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    secret: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = if (singleLine) 1 else 3,
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}
